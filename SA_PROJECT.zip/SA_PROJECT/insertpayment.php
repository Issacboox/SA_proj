<?php 
include 'connection.php';

if(isset($_POST['btn2'])) {
    $pro_id = $_POST['pro_id'];
    $id = $_POST['id'];
    $cus_name = $_POST['cusname'];
    $pay_money = $_POST['pay_money'];
    $pay_date = $_POST['pay_date'];
    $pay_time = $_POST['pay_time'];
    $file = $_FILES['file'];

    if(is_uploaded_file($file['tmp_name'])) {
        $new_image_name = 'b_' . uniqid() . "." . pathinfo(basename($file['name']), PATHINFO_EXTENSION);
        $image_upload_path = "img/payment/" . $new_image_name;
        move_uploaded_file($file['tmp_name'], $image_upload_path);
    } else {
        $new_image_name = "";
    }

    $sql = "INSERT INTO payment (pro_id,id,cus_name, pay_money, pay_date, pay_time, pay_img) VALUES ('$pro_id','$id','$cus_name', '$pay_money', '$pay_date', '$pay_time', '$new_image_name')";
    $hand = mysqli_query($conn, $sql);
    if ($hand) {
        echo "<script>window.location='buttons.php';</script>";
        echo "<script>alert('บันทึกข้อมูลเรียบร้อย');</script>";
    } else {
        echo "<script>alert('ไม่สามารถบันทึกข้อมูลได้');</script>";
    }
    mysqli_close($conn);
}
?>
