<?php 
 
    session_start();

    require_once "connection.php";

    if (isset($_POST['submit'])){

     $username =  $_POST['username'];
     $password =  $_POST['password'];
     $firstname =  $_POST['firstname'];
     $lastname =  $_POST['lastname'];
     $phone =  $_POST['phone'];
     $address =  $_POST['address'];
        
     $user_check = "SELECT * FROM user WHERE username ='$username' LIMIT 1";
     $result = mysqli_query($conn, $user_check);
     $user = mysqli_fetch_assoc($result);

     if ($user['username'] === $username) {
        echo "<script>alert('Username already exists');</script>";
     } else {
        $passwordenc = md5($password);

        $query = "INSERT INTO user (username, password, firstname, lastname, userlevel, phone , address) 
        VALUES ('$username', '$passwordenc', '$firstname', '$lastname', 'm' , '$phone','$address')";
        $result = mysqli_query($conn, $query);
     
  
        if ($result){
            $_SESSION['success'] = "Insert user successfully";
            header("Location: login_page.php");
        } else {
            $_SESSION['error'] = "Something went wrong" ;
            header("Location: login_page.php");
        }    
     }

    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Page</title>

    <link rel="stylesheet" href="register.css">

</head>
<body>
    
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

        <label for="username">Username</label>
        <input type="text" name="username" placeholder="Enter your username" required >
        
        <label for="password">Password</label>
        <input type="password" name="password" placeholder="Enter your password" required >
        
        <label for="firstname">Firstname</label>
        <input type="text" name="firstname" placeholder="Enter your firstname" required >
        
        <label for="lastname">Lastname</label>
        <input type="text" name="lastname" placeholder="Enter your lastname" required >
        
        <label for="phone">Phone number</label>
        <input type="text" name="phone" placeholder="Enter your Phone number" required >
       
        <label for="address">Address</label>
        <input type="text" name="address" placeholder="Enter your address" required >
        <br>
        <input type="submit" name="submit" value="Submit"><br>
        <a href="login_page.php">Already have accout</a>
    </form>

   

</body>
</html>