<?php
include 'connection.php';
$ids=$_GET['id'];

$sql="UPDATE tb_project SET pro_status = 3 WHERE pro_id='$ids' ";
$result=mysqli_query($conn,$sql);
if($result){
    echo "<script>alert('โครงการเสร็จสิ้น');</script>";
    echo "<script>window.location='tables.php';</script>";
}else{
    echo "<script>alert('ไม่สามารถปรับสถานะได้');</script>";
}
mysqli_close($conn);

?>