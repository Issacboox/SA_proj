<?php
include 'connection.php';
$id = $_POST["id"];
$address = $_POST["address"];
$telephone = $_POST["telephone"];
$email = $_POST["email"];
$budget = $_POST["budget"];
$file = $_FILES['blueprint'];


if(is_uploaded_file($file['tmp_name'])) {
    $new_image_name = 'blueprint_' . uniqid() . "." . pathinfo(basename($file['name']), PATHINFO_EXTENSION);
    $image_upload_path = "img/blueprint/" . $new_image_name;
    move_uploaded_file($file['tmp_name'], $image_upload_path);
} else {
    $new_image_name = "";
}

$sql = "INSERT INTO tb_project (id, address, telephone, email, budget,pro_status, blueprint) VALUES ('$id','$address','$telephone','$email','$budget','1','$new_image_name')";
$result = mysqli_query($conn, $sql);
if ($result) {
    echo "<script>window.location='add_proj.php' ;</script>";
    echo "<script>alert('บันทึกข้อมูลเรียบร้อย');</script>";
} else {
    echo "<script>alert('ไม่สามารถบันทึกข้อมูลได้');</script>";
}

mysqli_close($conn);
?>
