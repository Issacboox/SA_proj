<?php 
include("connection.php");
$repo_desc=$_REQUEST['desc'];

$sql = "INSERT INTO report_problem " ;
$sql = $sql." (repo_desc) " ;
$sql = $sql."  VALUES  " ;
$sql = $sql." ( \"".$repo_desc."\"   ) ";
//echo  " <BR> ".$sql." <BR> " ;

$result = mysqli_query($conn,$sql); 
 if($result)
 {  echo "<script>alert('รายงานปัญหาเรียบร้อยแล้ว');window.location='reports.php';</script>";   }
 else
 {  echo "<script>alert('เพิ่มข้อมูลไม่สำเร็จ');history.back();</script>";   }
?>