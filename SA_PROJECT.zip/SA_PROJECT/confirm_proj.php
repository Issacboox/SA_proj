<?php
include 'connection.php';
$ids=$_GET['id'];

$sql="UPDATE tb_project SET pro_status = 2 WHERE pro_id='$ids' ";
$result=mysqli_query($conn,$sql);
if($result){
    echo "<script>alert('ปรับสถานะเป็นกำลังดำเนินการเรียบร้อย');</script>";
    echo "<script>window.location='tables_admin_yes.php';</script>";
}else{
    echo "<script>alert('ไม่ปรับสถานะได้');</script>";
}
mysqli_close($conn);

?>