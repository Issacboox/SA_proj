<?php
include 'connection.php';
$ids=$_GET['id'];

$sql="UPDATE tb_project SET pro_status = 0 WHERE pro_id='$ids' ";
$result=mysqli_query($conn,$sql);
if($result){
    echo "<script>alert('ยกเลิกโครงการเรียบร้อย');</script>";
    echo "<script>window.location='tables.php';</script>";
}else{
    echo "<script>alert('ไม่สามารถลบข้อมูลได้');</script>";
}
mysqli_close($conn);

?>