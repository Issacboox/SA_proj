<?php

   $conn = mysqli_connect("localhost","root","","loginadmin");
   if(!$conn){
      die("Connection failed: " . mysqli_connect_error());
   }

?>